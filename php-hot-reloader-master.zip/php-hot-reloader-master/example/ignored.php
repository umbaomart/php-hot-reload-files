<!--  This file are setted to be ignored, so changes here will not trigger an autoreload -->
<p class="small">Php Hot Reloader by Felippe Regazio</p>