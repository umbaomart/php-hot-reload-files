// this file is being watched by the reloader, change it with your page oppened
console.log("The example.js file is running. Change this file will trigger an automatic reload");