<div class="live-example">
  <p>With this page opened in a browser, <br/>change this phrase, or any of its related files.</p>
</div>