// This file is being ignored due the attr hidden on its tag,
// Use the hidden tag on links/scripts tags to unwatch them
// So those files wont trigger an autoreload when changed
console.log("The ignored.js file is running but not triggering a page reload when changed");